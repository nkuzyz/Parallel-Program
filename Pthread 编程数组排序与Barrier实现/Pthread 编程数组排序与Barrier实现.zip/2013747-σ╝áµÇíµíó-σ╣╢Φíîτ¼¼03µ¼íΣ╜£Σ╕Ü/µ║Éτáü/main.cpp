#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <time.h>
#include <pthread.h>
#include <sys/time.h> // for gettimeofday()
//#include <unistd.h>
using namespace std;


typedef struct{
    int threadId;
} threadParm_t;

const int ARR_NUM = 10000;
const int ARR_LEN = 10000;
const int THREAD_NUM = 4;
const int seg = ARR_NUM / THREAD_NUM;

int next_arr = 0;
int taskNum = 2500;
vector<int> arr[ARR_NUM];
pthread_mutex_t mutex_lock= PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_task= PTHREAD_MUTEX_INITIALIZER;

struct timeval tpstart,tpend;

long long result[3][THREAD_NUM];




// 正常情况下的初始化待排序数组
void init_1(void){
    srand(unsigned(time(nullptr)));
    for (int i = 0; i < ARR_NUM; i++) {
        arr[i].resize(ARR_LEN);
        for (int j = 0; j < ARR_LEN; j++){
            arr[i][j] = rand();
        }
    }
}

// 初始化待排序数组，使得
// 第一段：完全升序
// 第二段：1/4逆序，3/4升序
// 第三段：1/2逆序，1/2升序
// 第四段：完全逆序
void init_2(void){
    int ratio;
    srand(unsigned(time(nullptr)));
    for (int i = 0; i < ARR_NUM; i++){
        arr[i].resize(ARR_LEN);
        if(i < seg)ratio = 0;
        else if(i < seg * 2)ratio = 32;
        else if(i < seg * 3)ratio = 64;
        else ratio = 128;
        if((rand() & 127) < ratio){
            for(int j = 0; j < ARR_LEN; j++){
                arr[i][j] = ARR_LEN - j;
            }
        }
        else{
            for(int j = 0; j < ARR_LEN; j++){
                arr[i][j] = j;
            }
        }
    }
}

// 块划分：每个线程负责连续n/4个数组的排序
void *arr_sort_1(void *parm){
    threadParm_t *p = (threadParm_t *) parm;
    int r = p->threadId;
    long long tail;
    for (int i = r * seg; i < (r + 1) * seg; i++){
        stable_sort(arr[i].begin(), arr[i].end());
    }
    pthread_mutex_lock(&mutex_lock);
    gettimeofday(&tpend,NULL);
    result[0][p->threadId] = (1000000*(tpend.tv_sec-tpstart.tv_sec)+tpend.tv_usec-tpstart.tv_usec)/1000;//注意，秒的读数和微秒的读数都应计算在内
    pthread_mutex_unlock(&mutex_lock);
    pthread_exit(nullptr);
}

// 动态获取：加锁，每个线程动态获取任务
void *arr_sort_2(void *parm) {
    threadParm_t *p = (threadParm_t *) parm;
    int task = 0;
    while (1) {
        pthread_mutex_lock(&mutex_task);
        task = next_arr++;
        pthread_mutex_unlock(&mutex_task);
        if (task >= ARR_NUM) break;
        stable_sort(arr[task].begin(), arr[task].end());
    }
    pthread_mutex_lock(&mutex_lock);
    gettimeofday(&tpend,NULL);
    result[1][p->threadId] = (1000000*(tpend.tv_sec-tpstart.tv_sec)+tpend.tv_usec-tpstart.tv_usec)/1000;//注意，秒的读数和微秒的读数都应计算在内


    pthread_mutex_unlock(&mutex_lock);
    pthread_exit(nullptr);
}

// 粗粒度动态获取：加锁，每个线程动态获取任务，一次性获取一部分任务
void *arr_sort_3(void *parm) {
    threadParm_t *p = (threadParm_t *) parm;
    int startTask = 0;
    int endTask = 0;
    long long tail;
    while (1) {
        pthread_mutex_lock(&mutex_task);
        startTask = next_arr;
        //每次分配100行
        endTask = next_arr + taskNum;
        next_arr = endTask;
        pthread_mutex_unlock(&mutex_task);
        if(startTask >= ARR_NUM) break;
        for(;startTask<endTask;startTask++){
            stable_sort(arr[startTask].begin(), arr[startTask].end());
        }
    }
    pthread_mutex_lock(&mutex_lock);
    gettimeofday(&tpend,NULL);
    result[2][p->threadId] = (1000000*(tpend.tv_sec-tpstart.tv_sec)+tpend.tv_usec-tpstart.tv_usec)/1000;//注意，秒的读数和微秒的读数都应计算在内

    pthread_mutex_unlock(&mutex_lock);
    pthread_exit(nullptr);
}


void test_1(void){
    pthread_t thread[THREAD_NUM];
    threadParm_t threadParm[THREAD_NUM];
    init_2();
    gettimeofday(&tpstart,NULL);
    for(int i = 0; i < THREAD_NUM; i++){
        threadParm[i].threadId = i;
        pthread_create(&thread[i], nullptr, arr_sort_1, (void *)&threadParm[i]);
    }
    for(int i = 0; i < THREAD_NUM; i++){
        pthread_join(thread[i], nullptr);
    }
    cout<<"连续块划分:"<<endl;
    for(int i = 0; i < THREAD_NUM; i++){
//        cout<<"Thread"<<i<<":"<<result[0][i]<<"ms"<<endl;
        cout<<result[0][i]<<endl;
    }
}

void test_2(void) {
    pthread_t thread[THREAD_NUM];
    threadParm_t threadParm[THREAD_NUM];
    init_2();
    gettimeofday(&tpstart, NULL);
    for (int i = 0; i < THREAD_NUM; i++) {
        threadParm[i].threadId = i;
        pthread_create(&thread[i], nullptr, arr_sort_2, (void *) &threadParm[i]);
    }
    for (int i = 0; i < THREAD_NUM; i++) {
        pthread_join(thread[i], nullptr);
    }
    cout << endl << "动态任务划分:" << endl;
    for (int i = 0; i < THREAD_NUM; i++) {
//        cout<<"Thread"<<i<<":"<<result[1][i]<<"ms"<<endl;
        cout << result[1][i] << endl;
    }

}

void test_3(void){
    pthread_t thread[THREAD_NUM];
    threadParm_t threadParm[THREAD_NUM];
    init_2();
    next_arr = 0;
    gettimeofday(&tpstart,NULL);
    for(int i = 0; i < THREAD_NUM; i++){
        threadParm[i].threadId = i;
        pthread_create(&thread[i], nullptr, arr_sort_3, (void *)&threadParm[i]);
    }
    for(int i = 0; i < THREAD_NUM; i++){
        pthread_join(thread[i], nullptr);
    }
    cout<<endl<<"粗粒度动态任务划分:"<<endl;
    for(int i = 0; i < THREAD_NUM; i++){
//        cout<<"Thread"<<i<<":"<<result[2][i]<<"ms"<<endl;
        cout<<result[2][i]<<endl;
    }
}
int main(int argc, char *argv[]){

    test_3();
    pthread_mutex_destroy(&mutex_lock);
    pthread_mutex_destroy(&mutex_task);
}
